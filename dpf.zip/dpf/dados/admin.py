from django.contrib import admin
from .models import Dado

admin.site.register(Dado)
